package com.aniruddha;

import java.util.List;

public class Blog {

	private List<Post> posts;
	public Blog() {
		posts=new ArrayList<>();
	}
	
	public void addPost(Post post) {
		posts.add(post);
	}
	
	public List<Posts> getPosts(){
		return posts;
	}
}
