package com.aniruddha;

import java.util.Date;

public class BlogEngine {

	public static void main(String[] args) {
		
		Blog blog= new Blog();
		Post post1=new Post(" ");
		Post post2= new Post(" ");
		blog.addPost(post1);

		blog.addPost(post2);
		
		List<Post> posts=blog.getPosts();
		for(Post post: posts) {
			System.out.println(posts);
		}

	}

}

