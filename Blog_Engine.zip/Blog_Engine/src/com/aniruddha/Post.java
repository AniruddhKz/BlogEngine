package com.aniruddha;

public class Post {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
